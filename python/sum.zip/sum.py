#To sum two numbers and print the result on the terminal
x= input("Enter the first number: ")
y= input("Enter the second number: ")
a,b = int(x),int(y)
c = a + b
print ("\n\t", "The sum of " + str (a) + " and " + str(b) + " is " + str(c),"\n")
input("press enter to exit")
